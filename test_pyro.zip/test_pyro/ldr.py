import torch
import matplotlib.pyplot as plt

data_num=1000
data_num1=data_num
data_num2=data_num

mu1=1.0
sigma1=1.

mu2=0.
sigma2=1.5


#zero = 0.*torch.randn(data_num)
data1 = torch.randn(data_num1,1)
data2 = torch.randn(data_num2,1)
data1 = mu1 + data1*sigma1
data2 = mu2 + data2*sigma2


plot_data = torch.linspace(torch.min(data1.min(),data2.min()), torch.max(data1.max(),data2.max()), steps=data_num*10)

err1 = plot_data-mu1
err1 = err1*err1/(sigma1*sigma1)

err2 = plot_data-mu2
err2 = err2*err2/(sigma2*sigma2)

err = -0.5*(err1 - err2)


class Model(torch.nn.Module):
    def __init__(self, D_in, H, D_out):
        super().__init__()
        self.l1 = torch.nn.Linear(D_in, H)
        #self.relu1 = torch.nn.ReLU()
        #self.l2=torch.nn.Linear(H, D_out)
        self.l2=torch.nn.Linear(H, H)
        #self.relu2 = torch.nn.ReLU()
        self.l3=torch.nn.Linear(H, D_out)

    def forward(self, X):
        #return self.l2(self.relu1(self.l1(X)))
        #return self.l3(self.relu2(self.l2(self.relu1(self.l1(X)))))
        return self.l3(torch.tanh(self.l2(torch.tanh(self.l1(X)))))

H = 4
model = Model(1, H, 1)
learning_rate = 1e-3
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=0.000)
#optimizer = torch.optim.SGD(model.parameters(), lr=.5)



target1 = torch.ones([data_num1,1], dtype=torch.float32)
target2 = torch.zeros([data_num2,1], dtype=torch.float32)
target = torch.cat((target1, target2), 0)


temp_loss = torch.nn.BCEWithLogitsLoss()

#weight1 = torch.ones([data_num1,1], dtype=torch.float32)/data_num1
#weight2 = torch.ones([data_num2,1], dtype=torch.float32)/data_num2
#weight = torch.cat((weight1, weight2), 0)
#temp_loss = torch.nn.BCEWithLogitsLoss(weight=weight)

original_data = torch.cat((data1, data2), 0)


class DataSet:
    def __init__(self, X, t):
        self.X = X
        self.t = t

    def __len__(self):
        return len(self.X)

    def __getitem__(self, index):
        return self.X[index], self.t[index]

dataset = DataSet(original_data, target)
dataloader = torch.utils.data.DataLoader(dataset, batch_size=100, shuffle = True)

for epoch in range(2000):

    for data in dataloader:
        X = data[0]
        t = data[1]
        optimizer.zero_grad()

        loss = temp_loss(model(X), t)

        loss.backward()

        optimizer.step()
    print(epoch, loss.item())


from torch.autograd import Variable
#test_input= Variable(torch.FloatTensor(data1), requires_grad=False)
#y_last = model(test_input).detach().numpy()
y_last = model(original_data).detach().numpy()


#print(data1)
import numpy as np

plt.plot(data1,np.zeros(data_num1),"x")
plt.plot(data2,np.ones(data_num2),"o")
plt.plot(plot_data,err)
plt.plot(original_data,y_last,"x")
plt.plot(original_data,np.exp(y_last),"x")
#plt.plot(data,y_last,"x")
#plt.xlim([-1,3])
plt.show()
