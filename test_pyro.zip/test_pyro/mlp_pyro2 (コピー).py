import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import datasets
from torchvision import transforms

import pyro
from pyro.distributions import Normal
from pyro.distributions import Categorical
from pyro.optim import Adam
from pyro.infer import SVI
from pyro.infer import Trace_ELBO

import matplotlib.pyplot as plt
import seaborn as sns
sns.set()


#train_loader = torch.utils.data.DataLoader(datasets.MNIST("/tmp/mnist", train=True, download=True,transform=transforms.Compose([transforms.ToTensor(),])),batch_size=128, shuffle=True)

#test_loader = torch.utils.data.DataLoader(datasets.MNIST("/tmp/mnist",train=False,transform=transforms.Compose([transforms.ToTensor(),])))

N = 10
#D_in = 1000
#D_out = 10
D_in = 1
D_out = 1


#x = np.array([[-2,-1,0,1,2]]).T
x = np.array([[1,2]]).T
x = x.astype(np.float32)
x = torch.from_numpy(x).clone()


x = torch.randn(N, D_in)
#y = torch.randn(N, D_out)
#y = -torch.sin(x)
y = -3.*x

class BNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(BNN, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size) # first layer
        self.out = nn.Linear(hidden_size, output_size)
        
    def forward(self, x):
        return self.out(F.relu(self.fc1(x)))
        #return self.out(torch.tanh(self.fc1(x)))

net = BNN(D_in, 1, D_out)

def model(x_data, y_data):
    # define prior destributions
    fc1w_prior = Normal(loc=torch.zeros_like(net.fc1.weight), scale=torch.ones_like(net.fc1.weight))
    fc1b_prior = Normal(loc=torch.zeros_like(net.fc1.bias), scale=torch.ones_like(net.fc1.bias))
    outw_prior = Normal(loc=torch.zeros_like(net.out.weight), scale=torch.ones_like(net.out.weight))
    outb_prior = Normal(loc=torch.zeros_like(net.out.bias), scale=torch.ones_like(net.out.bias))
    #sigma_prior = Normal(loc=torch.zeros_like(net.out.bias), scale=torch.ones_like(net.out.bias))
    
    priors = {
        'fc1.weight': fc1w_prior,
        'fc1.bias': fc1b_prior,
        'out.weight': outw_prior,
        'out.bias': outb_prior}
    
    lifted_module = pyro.random_module("module", net, priors)
    lifted_reg_model = lifted_module()
    prediction_mean = lifted_reg_model(x_data)
    #return lifted_module()
    
    #lhat = F.log_softmax(lifted_reg_model(x_data))
    #lhat = lifted_reg_model(x_data)
    #pyro.sample("obs", Categorical(logits=lhat), obs=y_data)
    #pyro.sample("obs", Normal(prediction_mean, 0.1 * torch.ones(x_data.size(0))), obs=y_data)
    pyro.sample("obs", Normal(prediction_mean, torch.ones(x_data.size(0))), obs=y_data)



def guide(x_data, y_data):

    # hyperparameter
    fc1w_mu_param = pyro.param("fc1w_mu", torch.randn_like(net.fc1.weight)) 
    fc1b_mu_param = pyro.param("fc1b_mu", torch.randn_like(net.fc1.bias))
    outw_mu_param = pyro.param("outw_mu", torch.randn_like(net.out.weight))
    outb_mu_param = pyro.param("outb_mu", torch.randn_like(net.out.bias))

    fc1w_sigma_param = F.softplus(pyro.param("fc1w_sigma", torch.randn_like(net.fc1.weight)))
    fc1b_sigma_param = F.softplus(pyro.param("fc1b_sigma", torch.randn_like(net.fc1.bias)))
    outw_sigma_param = F.softplus(pyro.param("outw_sigma", torch.randn_like(net.out.weight)))
    outb_sigma_param = F.softplus(pyro.param("outb_sigma", torch.randn_like(net.out.bias)))


    fc1w_prior = Normal(loc=fc1w_mu_param, scale=fc1w_sigma_param)

    fc1b_prior = Normal(loc=fc1b_mu_param, scale=fc1b_sigma_param)

    outw_prior = Normal(loc=outw_mu_param, scale=outw_sigma_param).independent(1)

    outb_prior = Normal(loc=outb_mu_param, scale=outb_sigma_param)
    
    priors = {
        'fc1.weight': fc1w_prior,
        'fc1.bias': fc1b_prior,
        'out.weight': outw_prior,
        'out.bias': outb_prior}
    
    lifted_module = pyro.random_module("module", net, priors)
    
    return lifted_module()

optim = Adam({"lr": 0.1})


svi = SVI(model, guide, optim, loss=Trace_ELBO())

n_iterations = 5
loss = 0

#for name, value in pyro.get_param_store().items():
#    print(name, pyro.param(name))

for j in range(n_iterations):
    loss = 0
    #for batch_id, data in enumerate(train_loader):
    #    loss += svi.step(data[0].view(-1,28*28), data[1])
    loss += svi.step(x, y)

    #normalizer_train = len(train_loader.dataset)
    #total_epoch_loss_train = loss / normalizer_train
    total_epoch_loss_train = loss
    
    print("Epoch ", j, " Loss ", total_epoch_loss_train)

print("fc1w_mu",pyro.param("fc1w_mu").item())
print("fc1w_sigma",pyro.param("fc1w_sigma").item())
print("fc1b_mu",pyro.param("fc1b_mu").item())
print("fc1b_sigma",pyro.param("fc1b_sigma").item())
print("evaluate_loss =",svi.evaluate_loss(x, y))



n_samples = 1

def predict(x):
    sampled_models = [guide(None, None) for _ in range(n_samples)]
    yhats = [model(x).data for model in sampled_models]
    mean = torch.mean(torch.stack(yhats), 0)
    return mean
    #return np.argmax(mean.numpy(), axis=1)

print('Prediction when network is forced to predict')
correct = 0
total = 0
y_last = predict(x)



import matplotlib.pyplot as plt
plt.figure(figsize=(5,5))
plt.plot(x.detach().numpy(), y.detach().numpy(), 'o')
plt.plot(x.detach().numpy(), y_last, 'x')
plt.xlabel('x', fontsize=16)
plt.ylabel('y', fontsize=16)
plt.savefig('Model_validation')

#for j, data in enumerate(test_loader):
#for j in enumerate(1):
    #images, labels = data
    #predicted = predict(x)
    #total += labels.size(0)
    #correct += (predicted == labels).sum().item()
#print("accuracy: %d %%" % (100 * correct / total))

