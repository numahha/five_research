import torch
import numpy as np

N = 2
#D_in = 1000
#D_out = 10
D_in = 1
D_out = 1


x = torch.randn(N, D_in)
#y = torch.randn(N, D_out)
y = 2.*torch.sin(x*3.14)

class Model(torch.nn.Module):
    def __init__(self, D_in, H, D_out):
        super().__init__()
        self.l1 = torch.nn.Linear(D_in, H)
        self.relu = torch.nn.ReLU()
        self.l2=torch.nn.Linear(H, D_out)

    def forward(self, X):
        return self.l2(self.relu(self.l1(X)))


H = 2

model = Model(D_in, H, D_out)

loss_fn = torch.nn.MSELoss(reduction='sum')

#learning_rate = 1e-4
learning_rate = 1e-2
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
for t in range(50):
    y_pred = model(x)

    loss = loss_fn(y_pred, y)
    print(t, loss.item())

    optimizer.zero_grad()

    loss.backward()

    optimizer.step()



y_last = model(x)
loss = loss_fn(y_last, y)

y_error=y_last - y
#y_error=np.array(y_error.detach().numpy())
print("loss =",loss.item())
a=y_error*y_error
#print(y_error)
#print(a)
print(a.sum().detach().numpy())

import matplotlib.pyplot as plt
plt.figure(figsize=(5,5))
plt.plot(x.detach().numpy(), y.detach().numpy(), 'o')
plt.plot(x.detach().numpy(), y_last.detach().numpy(), 'x')
plt.xlabel('Targeted y', fontsize=16)
plt.ylabel('Modeled y', fontsize=16)
plt.savefig('Model_validation')



