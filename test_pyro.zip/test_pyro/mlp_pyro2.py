import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import datasets
from torchvision import transforms

import pyro
from pyro.distributions import Normal
from pyro.distributions import Categorical
from pyro.optim import Adam
from pyro.infer import SVI
from pyro.infer import Trace_ELBO

import matplotlib.pyplot as plt



N = 1000
#D_in = 1000
#D_out = 10
D_in = 1
D_out = 1


x = np.array([[-2,-1,0,1,2]]).T
#x = np.array([[2]]).T
x = x.astype(np.float32)
x = torch.from_numpy(x).clone()


x = torch.randn(N, D_in)
#y = torch.randn(N, D_out)
#y = -torch.sin(x)
y = -3.*x + torch.randn(N, D_out)

class BNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(BNN, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size) # first layer
        self.out = nn.Linear(hidden_size, output_size)
        
    def forward(self, x):
        #return self.out(F.relu(self.fc1(x)))
        return self.out(torch.tanh(self.fc1(x)))

net = BNN(D_in, 10, D_out)

from torch.distributions import constraints


def model(x_data, y_data, z_data):

    # define prior destributions
    prior_std = pyro.param("prior_std", torch.tensor([1.], requires_grad=True))
    fc1w_prior = Normal(loc=torch.zeros_like(net.fc1.weight), scale=F.softplus(prior_std)*torch.ones_like(net.fc1.weight))
    fc1b_prior = Normal(loc=torch.zeros_like(net.fc1.bias),   scale=F.softplus(prior_std)*torch.ones_like(net.fc1.bias))
    outw_prior = Normal(loc=torch.zeros_like(net.out.weight), scale=F.softplus(prior_std)*torch.ones_like(net.out.weight))
    outb_prior = Normal(loc=torch.zeros_like(net.out.bias),   scale=F.softplus(prior_std)*torch.ones_like(net.out.bias))

    
    priors = {
        'fc1.weight': fc1w_prior,
        'fc1.bias': fc1b_prior,
        'out.weight': outw_prior,
        'out.bias': outb_prior}
    
    lifted_module = pyro.random_module("module", net, priors)
    lifted_reg_model = lifted_module()
    prediction_mean = lifted_reg_model(x_data)
    #return lifted_module()

    #precision   = pyro.sample("precision", pyro.distributions.Gamma(prec_alpha, prec_beta))
    #noise_scale = 1 / precision.sqrt()
    #lhat = F.log_softmax(lifted_reg_model(x_data))
    #lhat = lifted_reg_model(x_data)
    #pyro.sample("obs", Categorical(logits=lhat), obs=y_data)
    #pyro.sample("obs", Normal(prediction_mean, 0.1 * torch.ones(x_data.size(0))), obs=y_data)
    #with pyro.plate("data", N), pyro.poutine.scale(scale=torch.ones(x_data.size(0))):

    noise_std = pyro.param("noise_std", torch.tensor([1.], requires_grad=True))
    with pyro.plate("data", x_data.size(0)), pyro.poutine.scale(scale=torch.ones(x_data.size(0))):
        pyro.sample("obs", Normal(prediction_mean, F.softplus(noise_std)*torch.ones(x_data.size(0))), obs=y_data)

    # https://forum.pyro.ai/t/inference-from-weighted-data-i-e-a-coreset/642

def guide(x_data, y_data, z_data):

    # hyperparameter
    fc1w_mu_param = pyro.param("fc1w_mu", torch.randn_like(net.fc1.weight)) 
    fc1b_mu_param = pyro.param("fc1b_mu", torch.randn_like(net.fc1.bias))
    outw_mu_param = pyro.param("outw_mu", torch.randn_like(net.out.weight))
    outb_mu_param = pyro.param("outb_mu", torch.randn_like(net.out.bias))
    #fc1w_mu_param = pyro.param("fc1w_mu", torch.randn_like(net.fc1.weight)) 
    #fc1b_mu_param = pyro.param("fc1b_mu", torch.randn_like(net.fc1.bias))
    #outw_mu_param = pyro.param("outw_mu", torch.randn_like(net.out.weight))
    #outb_mu_param = pyro.param("outb_mu", torch.randn_like(net.out.bias))

    fc1w_sigma_param = F.softplus(pyro.param("fc1w_sigma", torch.randn_like(net.fc1.weight)))
    fc1b_sigma_param = F.softplus(pyro.param("fc1b_sigma", torch.randn_like(net.fc1.bias)))
    outw_sigma_param = F.softplus(pyro.param("outw_sigma", torch.randn_like(net.out.weight)))
    outb_sigma_param = F.softplus(pyro.param("outb_sigma", torch.randn_like(net.out.bias)))


    fc1w_prior = Normal(loc=fc1w_mu_param, scale=fc1w_sigma_param)
    fc1b_prior = Normal(loc=fc1b_mu_param, scale=fc1b_sigma_param)
    outw_prior = Normal(loc=outw_mu_param, scale=outw_sigma_param)
    outb_prior = Normal(loc=outb_mu_param, scale=outb_sigma_param)
    
    priors = {
        'fc1.weight': fc1w_prior,
        'fc1.bias': fc1b_prior,
        'out.weight': outw_prior,
        'out.bias': outb_prior}
    
    lifted_module = pyro.random_module("module", net, priors)
    
    return lifted_module()


#optimizer = torch.optim.Adam(my_parameters, {"lr": 0.001, "betas": (0.90, 0.999)})
#loss_fn = pyro.infer.Trace_ELBO().differentiable_loss

optim = Adam({"lr": 0.1})
svi = SVI(model, guide, optim, loss=Trace_ELBO(num_particles=1))



n_iterations = 2000
loss = 0



for j in range(n_iterations):
    loss = 0
    #for batch_id, data in enumerate(train_loader):
    #    loss += svi.step(data[0].view(-1,28*28), data[1])
    loss += svi.step(x, y, x)
    #loss += loss_fn(model, guide)

    #normalizer_train = len(train_loader.dataset)
    #total_epoch_loss_train = loss / normalizer_train
    total_epoch_loss_train = loss
    
    print("Epoch ", j, " Loss ", total_epoch_loss_train)

for name, value in pyro.get_param_store().items():
    print(name, pyro.param(name))

#print("fc1w_mu",   pyro.param("fc1w_mu").item())
#print("fc1w_sigma",pyro.param("fc1w_sigma").item())
#print("fc1b_mu",   pyro.param("fc1b_mu").item())
#print("fc1b_sigma",pyro.param("fc1b_sigma").item())
#print("outw_mu",   pyro.param("outw_mu").item())
#print("outw_sigma",pyro.param("outw_sigma").item())
#print("outb_mu",   pyro.param("outb_mu").item())
#print("outb_sigma",pyro.param("outb_sigma").item())
print("evaluate_loss =",svi.evaluate_loss(x, y,x))

#print(optim.get_state())

n_samples = 100

def predict(x):
    sampled_models = [guide(None, None, None) for _ in range(n_samples)]
    yhats = [temp_model(x).data for temp_model in sampled_models]
    mean = torch.mean(torch.stack(yhats), 0)
    return mean
    #return np.argmax(mean.numpy(), axis=1)


correct = 0
total = 0
y_last = predict(x)

# loss = - ELBO


import matplotlib.pyplot as plt
plt.figure(figsize=(5,5))
plt.plot(x.detach().numpy(), y.detach().numpy(), 'o')
plt.plot(x.detach().numpy(), y_last, 'x')
plt.xlabel('x', fontsize=16)
plt.ylabel('y', fontsize=16)
plt.savefig('Model_validation')

#for j, data in enumerate(test_loader):
#for j in enumerate(1):
    #images, labels = data
    #predicted = predict(x)
    #total += labels.size(0)
    #correct += (predicted == labels).sum().item()
#print("accuracy: %d %%" % (100 * correct / total))

