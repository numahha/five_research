import GPy
import numpy as np
import matplotlib.pyplot as plt

# link: https://gpy.readthedocs.io/en/deploy/_modules/GPy/examples/regression.html


### training data
N = 2
#X = np.linspace(0.,1.,2)
#X=X[:, None]
X = np.array([[-2,-1,0,1,2]]).T

print("train_data_X", X)
#Y = np.sin(X) + np.random.randn(N,1)*0.05
#Y = np.sin(X)
Y = -3.0*X
print("train_data_Y", Y)



### regression
ndim=1
#kernel = GPy.kern.RBF(ndim, variance=1.0, lengthscale=None)
#kernel = GPy.kern.RBF(ndim, variance=22.5)
kernel = GPy.kern.RBF(ndim, variance=1.4, lengthscale=2.)
print("\n\nkernel definition")
print(kernel)
print("kernel.variance.values = ",kernel.variance.values)
print("kernel.lengscale.values = ",kernel.lengthscale.values)

print("\n\nregression model WITHOUT optimization")
model = GPy.models.GPRegression(X, Y, kernel, noise_var=1.0)
print(model)
print("model.Gaussian_noise.variance.values =",model.Gaussian_noise.variance.values)
print("ln_likelihood", model.log_likelihood())
print("ln_prior", model.log_prior())



### prediction
x_pred = np.array([[0.5]])
y_pred = model.predict(x_pred)
f_pred = model.predict_noiseless(x_pred)
print("x_pred is", x_pred)
print("y_pred_mean, y_pred_var =",y_pred)
print("f_pred_mean, f_pred_var =",f_pred)

#model.plot()
#plt.show()
#plt.savefig('fig3.png')



### hyperparameter optimization
#'''
print("\n\nregression model WITH optimization")
model.Gaussian_noise.fix()
model.optimize(messages=True, max_iters=1e5)
print(model)
print("kernel.variance.values = ",kernel.variance.values)
print("kernel.lengscale.values = ",kernel.lengthscale.values)
print("model.kern.variance.values = ",model.kern.variance.values)
print("model.Gaussian_noise.variance.values =",model.Gaussian_noise.variance.values)
print("ln_likelihood", model.log_likelihood())
print("ln_prior", model.log_prior())
### prediction 2
y_pred = model.predict(x_pred)
print("x_pred is", x_pred)
print("y_pred_mean, y_pred_var =",y_pred)
#model.plot()
#plt.show()
#'''
