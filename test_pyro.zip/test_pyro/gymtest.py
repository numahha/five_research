import gym
env = gym.make('Pendulum-v0')
observation = env.reset()
th_list=[]
ob_list=[]
ac_list=[]


for _ in range(200):
    env.render()
    action = env.action_space.sample() # your agent here (this takes random actions)
    observation, reward, done, info = env.step(action)
    th_list.append(env.env.state)
    ob_list.append(observation)
    ac_list.append(action)
    if done:
        observation = env.reset()

env.close()

import numpy as np
ob_list = np.array(ob_list)
ac_list = np.array(ac_list)
obac_list = np.concatenate((ob_list,ac_list),axis=1)
np.savetxt('np_obac.csv', obac_list[:-1,:],delimiter=',')
next_ob_list = ob_list[:-1,:] - ob_list[1:,:]
np.savetxt('np_nextob.csv', next_ob_list,delimiter=',')

#import matplotlib.pyplot as plt
#import math
#plt.plot(np.array(th_list)[:,0],ob_list[:,2])
#plt.show()
