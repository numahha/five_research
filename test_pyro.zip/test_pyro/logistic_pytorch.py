import torch
from sklearn.datasets import load_iris

iris = load_iris()
x = iris.data[:100]
y = iris.target[:100]
x = torch.tensor(x, dtype=torch.float32)
y = torch.tensor(y, dtype=torch.float32)

from torch import nn, optim

net = nn.Linear(in_features=4, out_features=1, bias=True)

optimizer = optim.SGD(net.parameters(), lr=0.25)

loss_fn = nn.BCEWithLogitsLoss()

losses = []

for epoc in range(100):
   optimizer.zero_grad()
   y_pred = net(x)
   loss = loss_fn(y_pred.view_as(y), y)
   loss.backward()
   optimizer.step()
   losses.append(loss.item())

print("x =",x)
print("y =",y)
print("x =",x.shape)
print("y =",y.shape)

from matplotlib import pyplot as plt
plt.plot(losses)
plt.show()

