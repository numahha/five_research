import numpy as np
from numpy.linalg import inv, det

w=-3


w_mu=-2.52
w_sigma=-0.56

w_sigma=np.log(1.+np.exp(w_sigma))

#x = np.array([[1,1,1,1,1]])
#k1 = x*x.T
x  = np.array([[2]])
k2 = x*x.T

y=(w-w_mu)*x


k = w_sigma*w_sigma*k2 + np.eye(1)


ln_p = -0.5*np.dot(np.dot(inv(k),y[0]), y[0]) - 0.5*np.log(2.*np.pi) - 0.5*np.log(det(k))
print(-ln_p)

print("yes",(-0.5*6*6 + (-6)*2*w_mu -0.5*w_sigma*w_sigma*4 -0.5*np.log(2.*np.pi)))

kld = .5*np.log(w_sigma*w_sigma) + (1.+w_mu*w_mu)/(2.*w_sigma*w_sigma) -0.5
print(kld)

print("yes",(-0.5*6*6 + (-6)*2*w_mu -0.5*w_sigma*w_sigma*4 -0.5*np.log(2.*np.pi))-kld)

kld = -.5*np.log(w_sigma*w_sigma) + (w_sigma*w_sigma+w_mu*w_mu)/(2.) -0.5
print(kld)

