import gym, custom_gym

import env_args
args = env_args.env_args()

env = gym.make(args.env)
o = env.reset()
th_list=[]
ob_list=[]
ac_list=[]

import torch
ac = torch.load('policy.pt')
def get_action(o, deterministic=True):
    return ac.act(torch.as_tensor(o, dtype=torch.float32), deterministic)

for _ in range(200):
    env.render()
    a = get_action(o, True)
    #a = env.action_space.sample() # your agent here (this takes random actions)
    o, reward, done, info = env.step(a)
    th_list.append(env.env.state)
    ob_list.append(o)
    ac_list.append(a)
    if done:
        o = env.reset()

env.close()

import numpy as np
ob_list = np.array(ob_list)
ac_list = np.array(ac_list)
obac_list = np.concatenate((ob_list,ac_list),axis=1)
np.savetxt('np_obac.csv', obac_list[:-1,:],delimiter=',')

next_ob_list = ob_list[1:,:] - ob_list[:-1,:]

# in case of pendlum, target is not [cos(th),sin(th)] but  th
th_list = np.array(th_list)[:,0]
th = th_list[1:] - th_list[:-1]
thdot = next_ob_list[:,2]
np.savetxt('np_nextob.csv',np.array([th,thdot]).T, delimiter=',')

#import matplotlib.pyplot as plt
#import math
#plt.plot(np.array(th_list)[:,0],ob_list[:,2])
#plt.show()
