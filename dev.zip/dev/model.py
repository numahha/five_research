import torch
import torch.nn.functional as F

class DynamicsModel(torch.nn.Module):
    def __init__(self, D_in, D_out, H):
        super().__init__()
        self.l1 = torch.nn.Linear(D_in, H)
        self.l2 = torch.nn.Linear(H, H)
        self.l3 = torch.nn.Linear(H, H)
        self.l4 = torch.nn.Linear(H, D_out)

    def forward(self, X):
        return self.l4(torch.tanh(self.l3(torch.tanh(self.l2(torch.tanh(self.l1(X)))))))
        #return self.l4(F.relu(self.l3(F.relu(self.l2(F.relu(self.l1(X)))))))
        #return self.l3(torch.tanh(self.l2(torch.tanh(self.l1(X)))))

class RatioModel(torch.nn.Module):
    def __init__(self, D_in, D_out, H):
        super().__init__()
        self.l1 = torch.nn.Linear(D_in, H)
        self.l2=torch.nn.Linear(H, H)
        self.l3=torch.nn.Linear(H, D_out)

    def forward(self, X):
        return self.l3(torch.tanh(self.l2(torch.tanh(self.l1(X)))))
        #return self.l3(torch.relu(self.l2(torch.relu(self.l1(X)))))
