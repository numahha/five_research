import argparse

def env_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--env', type=str, default='CustomPendulum-v0')
    parser.add_argument('--seed', '-s', type=int, default=0)
    parser.add_argument('--gamma', type=int, default=0.95)
    return parser.parse_args()
