import numpy as np
import matplotlib.pyplot as plt

def angle_normalize(x):
    return (((x+np.pi) % (2*np.pi)) - np.pi)


if __name__ == '__main__':

    #obac_data1 = np.loadtxt('np_obac.csv',delimiter=',')
    obac_data1 = np.loadtxt('np_obac_simulation.csv',delimiter=',')
    th1 = np.arccos(obac_data1[:,0])
    index = obac_data1[:,1]<0.
    th1[index] = -th1[index] + 2.*np.pi
    index = th1>5.
    th1[index] = th1[index] - 2.*np.pi

    plt.plot(th1[:40], obac_data1[:40,2])
    #plt.plot(th1, obac_data1[:,2],"o")


    """    
    weight = np.loadtxt('weight.csv',delimiter=',')
    index = weight>-0.01
    plt.scatter(x=th1[index], y=obac_data1[index,2], c=weight[index], cmap='jet')
    plt.colorbar()
    #"""

    """
    obac_data1 = np.loadtxt('np_obac_simulation.csv',delimiter=',')
    th1 = np.arccos(obac_data1[:,0])
    index = obac_data1[:,1]<0.
    th1[index] = -th1[index] + 2.*np.pi
    plt.plot(th1, obac_data1[:,2],"x")
    """

    '''
    obac_data2  = np.loadtxt('np_obac_sim.csv',delimiter=',')

    th2 = np.arccos(obac_data2[:,0])
    index = obac_data2[:,1]<0.
    th2[index] = -th2[index] + 2.*np.pi


    plt.plot(th2, obac_data2[:,2],"x")
    plt.ylim([-20,20])
    '''
    plt.show()
