# input (real data, policy)
import torch
import numpy as np


# tanh or relu
        #optimizer = torch.optim.SGD(self.model.parameters(), lr=1e-1,weight_decay=0.01)
        #optimizer = torch.optim.Adam(self.model.parameters(), lr=1e-3,weight_decay=0.01)

# cross validation

def get_sim_one_episode(sim_model, policy, init_dist, gamma):
    ob = init_dist()
    obac_list = []
    #while 1:
    for i in range(200):
        ac = policy(ob)
        obac = np.concatenate((ob,ac),axis=0)
        obac_list.append(obac)
        ob = sim_model(ob,ac)
        #if np.random.rand()>gamma:
        #    break
    return np.array(obac_list)


def get_sim_data(sim_model, policy, init_dist, gamma, data_num):
    sim_data = get_sim_one_episode(sim_model, policy, init_dist, gamma)
    sim_num  = sim_data.shape[0]
    while (sim_num<data_num):
        temp_data = get_sim_one_episode(sim_model, policy, init_dist, gamma)
        sim_num   = sim_num + temp_data.shape[0]
        sim_data = np.concatenate([sim_data, temp_data], 0)
    #np.random.shuffle(sim_data)
    return torch.from_numpy((sim_data[:data_num]).astype(np.float32)).clone()
    #return sim_data[:data_num]



class DataSet:
    def __init__(self, X, t):
        self.X = X

    def __len__(self):
        return len(self.X)

    def __getitem__(self, index):
        return self.X[index]


class RatioEstimation():
    def __init__(self, real_data, H=32):

        self.real_data = torch.from_numpy(real_data.astype(np.float32)).clone()
        self.input_dim = real_data.shape[1]
        self.real_data_num = real_data.shape[0]
        print("[dens] input_dim =",self.input_dim)
        print("[dens] real_data_num =",self.real_data_num)
        self.batch_size=int(self.real_data_num/10)

        from model import RatioModel
        self.model = RatioModel(self.input_dim, 1, H)

        self.dataloader1 = torch.utils.data.DataLoader(self.real_data, batch_size=self.batch_size, shuffle=True, drop_last=True)
        self.simulator_flag=False


    def load_sim_data(self, sim_data):
        self.sim_data  = torch.from_numpy(sim_data.astype(np.float32)).clone()
        self.sim_data_num  = sim_data.shape[0]
        print("[dens] sim_data_num =",self.sim_data_num)
        self.dataloader2 = torch.utils.data.DataLoader(self.sim_data,  batch_size=self.batch_size, shuffle=True, drop_last=True)


    def load_simulator(self, sim_model, policy, init_dist, gamma, sim_data_num):
        self.simulator_flag=True
        self.sim_model = sim_model
        self.policy = policy
        self.init_dist = init_dist
        self.gamma = gamma
        self.sim_data_num = sim_data_num
        self.sim_data = get_sim_data(self.sim_model, self.policy, self.init_dist, self.gamma, self.sim_data_num)
        self.dataloader2 = torch.utils.data.DataLoader(self.sim_data, batch_size=self.batch_size, shuffle=True, drop_last=True)


    def train_model(self, input_loader=None, weight_decay=0.001):
        temp_loss = torch.nn.BCEWithLogitsLoss()
        #optimizer = torch.optim.SGD(self.model.parameters(), lr=1e-1,weight_decay=weight_decay)
        optimizer = torch.optim.Adam(self.model.parameters(), lr=1e-2,weight_decay=weight_decay)

        if input_loader==None:
            loader1 = self.dataloader1
            loader2 = self.dataloader2
        else:
            loader1 = input_loader[0]
            loader2 = input_loader[1]

        target_zero = torch.zeros([self.batch_size,1], dtype=torch.float32)
        target_one  = torch.ones([self.batch_size,1], dtype=torch.float32)
        target = torch.cat((target_zero, target_one), 0)

        for epoch in range(1000):
            for data1, data2 in zip(loader1, loader2):
                X = torch.cat((data1, data2), 0)
                optimizer.zero_grad()
                loss = temp_loss(self.model(X), target)
                loss.backward()
                optimizer.step()
            if self.simulator_flag and (epoch+1)%(10*int(self.sim_data_num/self.real_data_num))==0:
                self.sim_data = get_sim_data(self.sim_model, self.policy, self.init_dist, self.gamma, self.sim_data_num)
                self.dataloader2 = torch.utils.data.DataLoader(self.sim_data,  batch_size=self.batch_size, shuffle=True, drop_last=True)


    def evaluate_loss(self, input_data=None):

        if input_data==None:
            first_data  = self.real_data
            second_data = self.sim_data
        else:
            first_data  = input_data[0]
            second_data = input_data[1]
        temp_loss_zero = torch.nn.BCEWithLogitsLoss(reduction = 'mean')
        target_zero = torch.zeros([first_data.shape[0],1], dtype=torch.float32)
        loss_zero = temp_loss_zero(self.model(first_data), target_zero).detach().numpy()
        
        temp_loss_one = torch.nn.BCEWithLogitsLoss(reduction = 'mean')
        target_one = torch.ones([second_data.shape[0],1], dtype=torch.float32)
        loss_one = temp_loss_one(self.model(second_data), target_one).detach().numpy()
        
        return (second_data.shape[0]*loss_zero + first_data.shape[0]*loss_one) / (first_data.shape[0] + second_data.shape[0])



    def cross_validation(self, k=5, wd_list=[0.01, 0.001, 0.0001]): # 0.1 seems to0 large
        #memo_flag = self.simulator_flag
        #self.simulator_flag = False

        real_indx = np.array([i for i in range(self.real_data.shape[0])])
        sim_indx  = np.array([i for i in range(self.sim_data.shape[0])])
        real_indx = np.random.permutation(real_indx)
        sim_indx  = np.random.permutation(sim_indx)
        real_indx_subset = np.array_split(real_indx,k)
        sim_indx_subset = np.array_split(sim_indx,k)

        score_list=[]
        for wd in wd_list:
            temp_score=0.
            for i in range(k):
                test_real_indx  = real_indx_subset[i]
                test_sim_indx   = sim_indx_subset[i]
                train_real_indx = np.ones(self.real_data.shape[0],dtype=bool)
                train_sim_indx  = np.ones(self.sim_data.shape[0],dtype=bool)                                
                train_real_indx[test_real_indx] = False
                train_sim_indx[test_sim_indx]   = False

                temp_train = [self.real_data[train_real_indx], self.sim_data[train_sim_indx]]
                temp_test  = [self.real_data[test_real_indx], self.sim_data[test_sim_indx]]

                temp_loader1 = torch.utils.data.DataLoader(temp_train[0], batch_size=self.batch_size, shuffle=True, drop_last=True)
                temp_loader2 = torch.utils.data.DataLoader(temp_train[1], batch_size=self.batch_size, shuffle=True, drop_last=True)
                for i2 in range(5):
                    self.train_model(input_loader=[temp_loader1,temp_loader2],weight_decay=wd)
                    print(self.evaluate_loss(input_data=temp_train))
                # test
                temp = self.evaluate_loss(input_data=temp_test)
                print("weight_decay",wd,"k-fold",i,"score",temp)
                temp_score += temp/k
            score_list.append(temp_score)
            print(temp_score)
        print(score_list)
        #self.simulator_flag = memo_flag


    def output_weight(self):
        return np.exp((self.model(self.real_data)).detach().numpy())

    def save_model(self, filename='temp_ratio_model.pt'):
        torch.save(self.model, filename)

    def load_model(self, filename='temp_ratio_model.pt'):
        self.model = torch.load(filename)




if __name__ == '__main__':
    obac_data   = np.loadtxt('np_obac.csv',delimiter=',')
    nextob_data = np.loadtxt('np_nextob.csv',delimiter=',')

    #from regression import DynamicsRegression
    #test_model = DynamicsRegression(obac_data, nextob_data)
    #test_model.load_model()

    from gpr import GPR
    test_model = GPR(obac_data, nextob_data)


    temp_sim_model = test_model.sim_next_ob

    import torch
    policy_torch = torch.load('policy.pt')
    def temp_policy(ob_input, deterministic=True):
        return np.clip(policy_torch.act(torch.as_tensor(ob_input, dtype=torch.float32), deterministic), -2.5, 2.5)
        #return policy_torch.act(torch.as_tensor(ob_input, dtype=torch.float32),deterministic)


    def temp_init_dist():
        high = np.array([0.0*np.pi, 0.0])
        state = np.random.uniform(low=-high, high=high)
        return np.array([np.cos(state[0]+np.pi), np.sin(state[0]+np.pi), state[1]])

    temp_gamma = 0.95

    import matplotlib.pyplot as plt
    sim_data_example = get_sim_data(temp_sim_model, temp_policy, temp_init_dist, temp_gamma, 999)
    np.savetxt("np_obac_simulation.csv",sim_data_example,delimiter=',' )
    plt.plot(sim_data_example[:,0],sim_data_example[:,1],"x")
    plt.savefig("sim_data_cosx_sinx.png")
    plt.close()

 
    model = RatioEstimation(obac_data)
    #model.load_sim_data(np.loadtxt('np_obac2.csv',delimiter=','))
    model.load_simulator(temp_sim_model, temp_policy, temp_init_dist, temp_gamma, 9999)
    #model.cross_validation()

    
    #model.load_model()
    print(model.evaluate_loss())
    for i in range(5):
        model.train_model()
        model.save_model()
        np.savetxt('weight.csv',model.output_weight(),delimiter=',')
        print(model.evaluate_loss(),model.output_weight().sum()/obac_data.shape[0])
        plt.plot(model.output_weight())
        plt.show()


