# input (real data, policy)
import torch
import numpy as np



# fit
# # repeat (1) nn regression and (2) gaussian noise

obac_data   = np.loadtxt('np_obac.csv',delimiter=',')
nextob_data = np.loadtxt('np_nextob.csv',delimiter=',')

#obac_data   = torch.from_numpy(obac_data.astype(np.float32)).clone()
#nextob_data = torch.from_numpy(nextob_data.astype(np.float32)).clone()




class Model(torch.nn.Module):
    def __init__(self, D_in, D_out, H):
        super().__init__()
        self.l1 = torch.nn.Linear(D_in, H)
        self.l2 = torch.nn.Linear(H, H)
        self.l3 = torch.nn.Linear(H, D_out)

    def forward(self, X):
        return self.l3(torch.tanh(self.l2(torch.tanh(self.l1(X)))))



class DynamicsPointEstimation():
    def __init__(self, input_data, output_data, H=4):

        self.input_data   = torch.from_numpy(input_data.astype(np.float32)).clone()
        self.output_data  = torch.from_numpy(output_data.astype(np.float32)).clone()

        self.data_num   = input_data.shape[0]
        self.input_dim  = input_data.shape[1]
        self.output_dim = output_data.shape[1]

        self.data_weight = torch.ones(self.data_num,1)

        self.model = Model(self.input_dim, self.input_dim, H)

        self.optimizer = torch.optim.Adam(local_model.parameters(), lr=1e-2)

        self.noise_varianse_mle()

        #self.reward_function
        #self.lambda

    def noise_varianse_mle(self):
        self.noise_weight = torch.sum((nextob_data-model(obac_data).detach())**2, dim=0)/data_num

    def update_data_weight(self):
        print("to be implemented")

    def update_model(self):
        for t in range(50):
            self.optimizer.zero_grad()
            loss = torch.sum(weight_matrix*((self.model(obac_data)- self.output_data)** 2))
            print(t, loss.item())
            loss.backward()
            self.optimizer.step()





















def sgd_dynamics_model(local_model, local_data_weight):

    learning_rate = 1e-2
    local_optimizer = torch.optim.Adam(local_model.parameters(), lr=learning_rate)

    noise_weight = torch.sum((nextob_data-model(obac_data).detach())**2, dim=0)/data_num # noise varianse by maximum likelihood estimation
    weight_matrix = noise_weight*local_data_weight

    # to use mini batch

    for t in range(50):
        local_optimizer.zero_grad()
        loss = torch.sum(weight_matrix*((local_model(obac_data)- nextob_data)** 2))
        print(t, loss.item())
        loss.backward()
        local_optimizer.step()

    return local_model


def fit_dynamics_model(model=model):
    for i in range(10):
        model = sgd_dynamics_model(model,data_weight)



#fit_dynamics_model()















# density ratio
# # generate simulation sample
# # log density ratio estimation


obac_simulation_data   = np.loadtxt('np_obac1.csv',delimiter=',')
obac_simulation_data = torch.from_numpy(obac_simulation_data.astype(np.float32)).clone()

target1 = torch.zeros([data_num,1], dtype=torch.float32)
target2 = torch.ones([data_num,1], dtype=torch.float32)
target = torch.cat((target1, target2), 0)

ratio_estimation_data = torch.cat((obac_data, obac_simulation_data), 0)


class DansityRatioModel(torch.nn.Module):
    def __init__(self, D_in, D_out=1, H=16):
        super().__init__()
        self.l1 = torch.nn.Linear(D_in, H)
        self.l2=torch.nn.Linear(H, H)
        self.l3=torch.nn.Linear(H, D_out)

    def forward(self, X):
        return self.l3(torch.tanh(self.l2(torch.tanh(self.l1(X)))))

class DataSet:
    def __init__(self, X, t):
        self.X = X
        self.t = t

    def __len__(self):
        return len(self.X)

    def __getitem__(self, index):
        return self.X[index], self.t[index]

dataset = DataSet(ratio_estimation_data, target)
dataloader = torch.utils.data.DataLoader(dataset, batch_size=50)
temp_loss = torch.nn.BCEWithLogitsLoss()

learning_rate = 1e-3
ratio_model = DansityRatioModel(input_dim)
optimizer = torch.optim.Adam(ratio_model.parameters(), lr=learning_rate, weight_decay=0.000)

for epoch in range(5000):

    for data in dataloader:
        X = data[0]
        t = data[1]
        optimizer.zero_grad()

        loss = temp_loss(ratio_model(X), t)

        loss.backward()

        optimizer.step()
    print(epoch, loss.item())

import matplotlib.pyplot as plt
weight = np.exp(ratio_model(ratio_estimation_data).detach().numpy()[:200])
plt.plot(weight)
print(weight.sum())
plt.show()

# policy evaluation
# # initialize weight
# # repeat (1) fit and (2) density ratio
