import numpy as np
import GPy

def gpr(x, yi):
    kernel = GPy.kern.RBF(x.shape[1],ARD=True)
    model = GPy.models.GPRegression(x, yi, kernel)
    model.optimize(messages=True, max_iters=2e5)
    return model


class GPR():
    def __init__(self, input_data, output_data):

        # common part
        self.input_data  = np.copy(input_data)
        self.output_data = np.copy(input_data)

        self.data_num   = input_data.shape[0]
        self.input_dim  = input_data.shape[1]
        self.output_dim = output_data.shape[1]

        self.gpr_m1 = gpr(input_data, output_data[:,0].reshape((output_data[:,0].shape[0]),1))
        self.gpr_m2 = gpr(input_data, output_data[:,1].reshape((output_data[:,1].shape[0]),1))
        print("model1.Gaussian_noise.variance.values =",self.gpr_m1.Gaussian_noise.variance.values)
        print("model2.Gaussian_noise.variance.values =",self.gpr_m2.Gaussian_noise.variance.values)

    def onestepdynamics(self, obac):
    #def onestepdynamics(self, th, thdot, u):
    #    X = np.array([np.cos(th), np.sin(th), thdot, u])
    #    X=X[:,None].T
        # predict with noise, see GPy reference ``https://gpy.readthedocs.io/en/deploy/GPy.core.html''
        obac=obac[:,None].T
        y1_mu, y1_sigma=self.gpr_m1.predict(obac)
        y2_mu, y2_sigma=self.gpr_m2.predict(obac)

        newth    = ( y1_mu + np.sqrt(y1_sigma)*np.random.normal(0.,1.) ) 
        newthdot = ( y2_mu + np.sqrt(y2_sigma)*np.random.normal(0.,1.) )
        return np.array([newth[0,0], newthdot[0,0]])


    def sim_next_ob(self, ob, ac):
        obac = np.concatenate((ob,ac),axis=0)
        y = self.onestepdynamics(obac)
        #return ob + y

        # for pendulum
        next_ob = np.copy(ob)
        # cos(a+b) = cos(a)cos(b) - sin(a)sin(b)
        # sin(a+b) = sin(a)cos(b) + cos(a)sin(b)
        next_ob[0] = ob[0]*np.cos(y[0]) - ob[1]*np.sin(y[0])
        next_ob[1] = ob[1]*np.cos(y[0]) + ob[0]*np.sin(y[0])
        length = np.linalg.norm(next_ob[:2])
        next_ob[0]=next_ob[0]/length
        next_ob[1]=next_ob[1]/length
        next_ob[2] = ob[2] + y[1]
        return next_ob


if __name__ == '__main__':
    obac_data   = np.loadtxt('np_obac.csv',delimiter=',')
    nextob_data = np.loadtxt('np_nextob.csv',delimiter=',')

    test_model = GPR(obac_data, nextob_data)
    


    
