import numpy as np


def cost(ob,ac):
    th = np.arccos(ob[0])
    return th ** 2 + .1 * ob[2] ** 2 + .001 * (ac ** 2)


def get_sim_one_episode_ret(sim_model, policy, init_dist, gamma):
    ob = init_dist()
    ret=0.
    temp_gamma=1.
    for i in range(200):
        ac = policy(ob)
        ret += -temp_gamma*cost(ob,ac)
        obac = np.concatenate((ob,ac),axis=0)
        ob = sim_model(ob,ac)
        temp_gamma = temp_gamma*gamma
    return ret



if __name__ == '__main__':

    obac_data   = np.loadtxt('np_obac.csv',delimiter=',')
    nextob_data = np.loadtxt('np_nextob.csv',delimiter=',')

    #from regression import DynamicsRegression
    #test_model = DynamicsRegression(obac_data, nextob_data)
    #test_model.load_model()

    from gpr import GPR
    test_model = GPR(obac_data, nextob_data)

    import torch
    policy_torch = torch.load('policy.pt')
    def temp_policy(ob_input, deterministic=True):
        return policy_torch.act(torch.as_tensor(ob_input, dtype=torch.float32), deterministic)

    def temp_init_dist():
        high = np.array([0.1*np.pi, 0.1])
        state = np.random.uniform(low=-high, high=high)
        return np.array([np.cos(state[0]+np.pi), np.sin(state[0]+np.pi), state[1]])

    gamma=0.95
    ret_list=[]
    for i in range(200):
        ret = get_sim_one_episode_ret(test_model.sim_next_ob, temp_policy, temp_init_dist, gamma)
        ret_list.append(ret)
        print(i,ret)
    ret_list=np.array(ret_list)
    print("mean",ret_list.mean())
    print("std",ret_list.std())
