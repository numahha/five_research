import numpy as np
import torch
import gym, custom_gym

# rollout and 


def rollout(env_fn, 
            seed=0,
            gamma=1.,
            num_test_episodes=1000):

    torch.manual_seed(seed)
    np.random.seed(seed)
    env = env_fn()

    #ac = torch.load('/home/test/spinningup/data/sac/sac_s0/pyt_save/model.pt')
    ac = torch.load('policy.pt')
    def get_action(o, deterministic=True):
        return ac.act(torch.as_tensor(o, dtype=torch.float32), 
                      deterministic)

    ep_ret_list=[]
    for j in range(num_test_episodes):
        o, d, ep_ret, ep_len = env.reset(), False, 0, 0
        init_o=o
        temp_gamma=1
        while not d:
            a = get_action(o, True)
            o, r, d, _ = env.step(a)
            #print(o)
            ep_ret += temp_gamma*r
            ep_len += 1
            temp_gamma = temp_gamma*gamma
        #print(ep_ret,"init_ob =",init_o,"end_ob =",o)
        ep_ret_list.append(ep_ret)
        print(j)
    ep_ret_list = np.array(ep_ret_list)
    print("gamma",gamma)
    print("mean",ep_ret_list.mean())
    print("std",ep_ret_list.std())


if __name__ == '__main__':
    import env_args
    args = env_args.env_args()

    rollout(lambda : gym.make(args.env), 
        seed=args.seed,
        gamma=args.gamma)
