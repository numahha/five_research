import numpy as np
import torch
import gym, custom_gym

# draw value function for pendulum

def sac(env_fn, 
        seed=0, 
        num_test_episodes=10):

    torch.manual_seed(seed)
    np.random.seed(seed)
    env = env_fn()

    ac = torch.load('policy.pt')

    def get_action(o, deterministic=False):
        return ac.act(torch.as_tensor(o, dtype=torch.float32),deterministic)

    def get_value_function(o):
        with torch.no_grad():
            o_ = torch.as_tensor(o, dtype=torch.float32)
            a_ = torch.as_tensor(get_action(o, True), dtype=torch.float32)
            q1_pi = ac.q1(o_, a_)
            q2_pi = ac.q2(o_, a_)
        return torch.min(q1_pi, q2_pi).detach().clone().numpy()


    import matplotlib.pyplot as plt

    th     = np.linspace(0., 6.28)
    th_dot = np.linspace(-10., 10.)
    XI, YI = np.meshgrid(th, th_dot)

    import copy
    ZI = copy.deepcopy(XI)
    for i in range(XI.shape[0]):
        for j in range(XI.shape[1]):
            ZI[i,j] = get_value_function(np.array([np.cos(XI[i,j]),np.sin(XI[i,j]),YI[i,j]]))
    plt.pcolor(XI, YI, ZI)
    plt.colorbar()
    plt.show()
    

    '''
    for j in range(num_test_episodes):
        o, d, ep_ret, ep_len = env.reset(), False, 0, 0
        while not d:
            # Take deterministic actions at test time 
            o, r, d, _ = env.step(get_action(o, True))
            ep_ret += r
            ep_len += 1
            #print(get_value_function(o))
            print("o =",o)
        print(ep_ret)
    '''


if __name__ == '__main__':
    import env_args
    args = env_args.env_args()

    torch.set_num_threads(torch.get_num_threads())
    print("torch.get_num_threads() = ",torch.get_num_threads())

    sac(lambda : gym.make(args.env), 
        seed=args.seed)
