import numpy as np
import torch

# transition model: s'-s = f(s,a) + noise


# (ignore second term) vs. (use gradient approximation) || study for small/large parameters



class DataSet:
    def __init__(self, X, t):
        self.X = X
        self.t = t

    def __len__(self):
        return len(self.X)

    def __getitem__(self, index):
        return self.X[index], self.t[index], index


class DynamicsRegression():
    def __init__(self, input_data, output_data):

        # common part
        self.input_data  = torch.from_numpy(input_data.astype(np.float32)).clone()
        self.output_data = torch.from_numpy(output_data.astype(np.float32)).clone()

        self.data_num   = input_data.shape[0]
        self.input_dim  = input_data.shape[1]
        self.output_dim = output_data.shape[1]

        from model import DynamicsModel
        self.model = DynamicsModel(self.input_dim, self.output_dim, 64)

        #dataset = DataSet(self.input_data, self.output_data)
        #self.dataloader = torch.utils.data.DataLoader(dataset, batch_size=int(self.data_num/10), shuffle=True, drop_last=True)

        self.data_weight = torch.ones(self.data_num,1)
        self.noise_estimation()

        '''
        # for gradient approximation
        self.loss_model = Model(self.input_dim, 1, 1)
        self.loss_mean = torch.sum( self.loss_model(self.input_data) ).detach()/self.data_num
        '''


    def update_data_weight(self, data_weight):
        self.data_weight = torch.tensor(data_weight)


    def noise_estimation(self, index=None):
        if index is None:
            index = np.array([i for i in range(self.data_num)])
        X = self.input_data[index]
        t = self.output_data[index]
        #self.noise_weight = torch.sum((t-self.model(X).detach())**2, dim=0)/self.data_num
        self.noise_weight = torch.sum((t-self.model(X).detach())**2, dim=0)/X.shape[0]
        self.noise_std_np = np.sqrt(self.noise_weight.numpy())   
        self.weight_matrix = self.noise_weight*self.data_weight[index]


    def train_model(self, index=None, weight_decay=0.0000):
        optimizer = torch.optim.Adam(self.model.parameters(), lr=1e-3, weight_decay=weight_decay)
        self.noise_estimation(index=index)

        if index is None:
            index = np.array([i for i in range(self.data_num)])
        train_dataset = DataSet(self.input_data[index], self.output_data[index])
        temp_loader = torch.utils.data.DataLoader(train_dataset, batch_size=int(self.data_num/10), shuffle=True, drop_last=True)

        for epoch in range(5000):
            for data in temp_loader:
                X = data[0]
                t = data[1]
                i = data[2]
                optimizer.zero_grad()
                loss = torch.sum(self.weight_matrix[i]*((self.model(X)- t)** 2))
                loss.backward()
                optimizer.step()


    def log_likelihood(self, index=None):
        self.noise_estimation(index=index)
        if index is None:
            index = np.array([i for i in range(self.data_num)])
        X = self.input_data[index]
        t = self.output_data[index]
        wse = torch.sum(self.weight_matrix*((self.model(X)- t)** 2))
        return (-0.5*wse/X.shape[0] - 0.5*torch.sum( torch.log(2.*np.pi*self.noise_weight))).detach().numpy()


    #def cross_validation(self, k=5, wd_list=[0.0001, 0.000001, 0.00000001, 0.0000000001]):
    def cross_validation(self, k=5, wd_list=[0, 0.000001, 0.00000001, 0.0000000001]):
        indx = np.array([i for i in range(self.data_num)])
        indx = np.random.permutation(indx)
        indx_subset = np.array_split(indx,k)

        score_list=[]
        for wd in wd_list:
            temp_score=0.
            for i in range(k):
                print("weight_decay",wd,"k-fold",i)
                test_indx = indx_subset[i]
                train_indx = np.ones(self.data_num,dtype=bool)
                train_indx[test_indx] = False
                for i2 in range(1):
                    self.train_model(index=train_indx, weight_decay=wd)
                    print("temp_train_loss",-self.log_likelihood(index=train_indx))
                # test
                temp_score -= self.log_likelihood(index=test_indx)/k
                print("temp_test_loss",-self.log_likelihood(index=test_indx))
            score_list.append(temp_score)
            print("total_test_loss",temp_score)
        print(score_list)


    def view(self):
        print("[reg] log_likelihood =",self.log_likelihood())
        print("[reg] noise_variance =",self.noise_weight)

    def sim_next_ob(self, ob, ac):
        obac = np.concatenate((ob,ac),axis=0)
        pred = self.model( torch.from_numpy(obac.astype(np.float32)).clone() ).detach().numpy()
        noise = np.random.randn(self.output_dim) * self.noise_std_np
        y = pred + noise
        #return ob + y

        # for pendulum
        next_ob = np.copy(ob)
        # cos(a+b) = cos(a)cos(b) - sin(a)sin(b)
        # sin(a+b) = sin(a)cos(b) + cos(a)sin(b)
        next_ob[0] = ob[0]*np.cos(y[0]) - ob[1]*np.sin(y[0])
        next_ob[1] = ob[1]*np.cos(y[0]) + ob[0]*np.sin(y[0])
        length = np.linalg.norm(next_ob[:2])
        next_ob[0]=next_ob[0]/length
        next_ob[1]=next_ob[1]/length
        next_ob[2] = np.clip(ob[2] + y[1],-8.,8)
        return next_ob

    def save_model(self, filename='temp_dynamics_model.pt'):
        torch.save(self.model, filename)

    def load_model(self, filename='temp_dynamics_model.pt'):
        self.model = torch.load(filename)
        print("load ",filename)


    '''
    # for gradient approximation
    def train_loss_model(self):

        self.noise_estimation()
        temp_weight_matrix = self.noise_weight*torch.ones(self.data_num,1)
        se = torch.sum(temp_weight_matrix*((self.model(self.input_data)- self.output_data)** 2), dim=1)
        temp_target = -(-0.5*se -0.5 *torch.sum( torch.log(2.*np.pi*self.noise_weight))).detach()

        optimizer = torch.optim.Adam(self.loss_model.parameters(), lr=1e-2)
        temp_dataset = DataSet(self.input_data, temp_target)
        temp_dataloader = torch.utils.data.DataLoader(temp_dataset, batch_size=100, shuffle = True, drop_last=True)

        for epoch in range(1000):

            for data in temp_dataloader:
                X = data[0]
                t = data[1]
                optimizer.zero_grad()
                loss = torch.sum((self.loss_model(X)- t)** 2)
                loss.backward()
                optimizer.step()

        #print( torch.sum((self.loss_model(self.input_data) - temp_target)** 2).detach()/self.data_num )
        #print( temp_target.sum()/self.data_num )
        self.loss_mean = torch.sum( self.loss_model(self.input_data) ).detach()/self.data_num


    def loss_model_function(self, sa):
        return (self.loss_model(torch.from_numpy(sa.astype(np.float32)).clone()).detach() - self.loss_mean).numpy()
    '''
 

if __name__ == '__main__':
    obac_data   = np.loadtxt('np_obac.csv',delimiter=',')
    nextob_data = np.loadtxt('np_nextob.csv',delimiter=',')

    test_model = DynamicsRegression(obac_data, nextob_data)
    test_model.cross_validation()
    test_model.load_model()
    for i in range(10):
        test_model.train_model()
        test_model.save_model()
        test_model.view()

    
