import numpy as np
from regression import DynamicsRegression
from ratio_estimation import RatioEstimation

if __name__ == '__main__':
    obac_data   = np.loadtxt('np_obac.csv',delimiter=',')
    nextob_data = np.loadtxt('np_nextob.csv',delimiter=',')

    # construct model
    dynamics_model = DynamicsRegression(obac_data, nextob_data)
    ratio_model = RatioEstimation(obac_data)


    #data_weight = ratio_model.output_weight()
    data_weight = np.ones((obac_data.shape[0],1), dtype="float32")
    dynamics_model.update_data_weight(data_weight)


    # train dynamics model
    dynamics_model.train_model_loop()

    # generate sim data
    obac_simulation_data = np.loadtxt('np_obac1.csv',delimiter=',')

    # update sim data
    ratio_model.load_sim_data(obac_simulation_data)

    # train ratio model
    ratio_model.train_model_loop()
    data_weight = ratio_model.output_weight()

