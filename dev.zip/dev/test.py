import numpy as np
th1=0.1
th2=0.3

print(np.cos(th1+th2))
print(np.cos(th1)*np.cos(th2)-np.sin(th1)*np.sin(th2))

print(np.sin(th1+th2))
print(np.sin(th1)*np.cos(th2)+np.cos(th1)*np.sin(th2))
